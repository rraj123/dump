#!/bin/bash

source .env

docker container rm -f ${CONTAINER}

