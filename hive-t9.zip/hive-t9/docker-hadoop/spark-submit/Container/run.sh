#!/bin/bash

#$HADOOP_PREFIX/bin/hadoop jar $JAR_FILEPATH $CLASS_TO_RUN $PARAMS 
#$SPARK_HOME/bin/spark-submit --class "Accumulator" --master local[4]  spark-accumlator_2.11-2.11.8.jar
ls 
echo "Here is the JAVA Home " $JAVA_HOME
echo "Here is the Spark Home " $SPARK_HOME
echo "Here is the Scala Home " $SCALA_HOME
echo "The whole path ===> " $PATH
echo $SPARK_HOME/bin/spark-submit $CLASS_TO_RUN $PARAMS $JAR_FILEPATH 

$SPARK_HOME/bin/spark-submit $CLASS_TO_RUN $PARAMS $JAR_FILEPATH