export HADOOP_CONF_DIR=/opt/hadoop-3.1.3/etc/hadoop
export YARN_CONF_DIR=/opt/hadoop-3.1.3/etc/hadoop
export SPARK_DIST_CLASS_PATH=$(hadoop --config /opt/hadoop-3.1.3/etc/hadoop classpath)