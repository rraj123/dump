#!/bin/bash

# hadoop fs -mkdir       /tmp
# hadoop fs -mkdir -p    /user/hive/warehouse
# hadoop fs -chmod g+w   /tmp
# hadoop fs -chmod g+w   /user/hive/warehouse

cd $HIVE_HOME/bin
# ./hiveserver2 --hiveconf hive.server2.enable.doAs=false
# hive --service metastore 1>> /tmp/meta.log 2>> /tmp/meta.log &
# hive --service hiveserver2 1>> /tmp/hs2.log 2>> /tmp/hs2.log
#schematool -dbType postgres -initSchema --verbose && hive --service metastore 

hive --service hiveserver2