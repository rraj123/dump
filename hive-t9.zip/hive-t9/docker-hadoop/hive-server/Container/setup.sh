#!/bin/sh

#if [ -d /etc/apt ]; then
#        [ -n "$http_proxy" ] && echo "Acquire::http::proxy \"${http_proxy}\";" > /etc/apt/apt.conf; \
#        [ -n "$https_proxy" ] && echo "Acquire::https::proxy \"${https_proxy}\";" >> /etc/apt/apt.conf; \
#        [ -f /etc/apt/apt.conf ] && cat /etc/apt/apt.conf
#fi

# Upgrade system
apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
      openjdk-8-jdk \
      net-tools \
      curl \
      netcat \
      gnupg \
      wget \
      telnet \
      nginx \
      vim \
    && rm -rf /var/lib/apt/lists/*

# Set Java and Build Version
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64/

#Get the keys for Hadoop Distribution
curl -O https://dist.apache.org/repos/dist/release/hadoop/common/KEYS

gpg --import KEYS

export HADOOP_VERSION=3.1.3
export HADOOP_URL=https://www.apache.org/dist/hadoop/common/hadoop-$HADOOP_VERSION/hadoop-$HADOOP_VERSION.tar.gz

set -x \
    && curl -fSL "$HADOOP_URL" -o /tmp/hadoop.tar.gz \
    && curl -fSL "$HADOOP_URL.asc" -o /tmp/hadoop.tar.gz.asc \
    && gpg --verify /tmp/hadoop.tar.gz.asc \
    && tar -xvf /tmp/hadoop.tar.gz -C /opt/ \
    && rm /tmp/hadoop.tar.gz*

mv /opt/hadoop-$HADOOP_VERSION /opt/hadoop

ln -s /opt/hadoop/etc/hadoop /etc/hadoop

mkdir /opt/hadoop/logs

mkdir /hadoop-data

# #Add Spark and Scala 
export SPARK_VERSION=2.4.4
export SPARK_HADOOP_VERSION=2.7
export SPARK_DIR_PATH=spark-$SPARK_VERSION-bin-hadoop$SPARK_HADOOP_VERSION

curl -O https://dist.apache.org/repos/dist/release/spark/KEYS

gpg --import KEYS
                                                                                        
export SPARK_URL=https://www.apache.org/dist/spark/spark-$SPARK_VERSION/spark-$SPARK_VERSION-bin-hadoop$SPARK_HADOOP_VERSION.tgz

mkdir spark-temp

set -x \
    && curl -fSL "$SPARK_URL" -o /tmp/spark.tgz \
    && curl -fSL "$SPARK_URL.asc" -o /tmp/spark.tgz.asc \
    && gpg --verify /tmp/spark.tgz.asc \
    && tar -xvf /tmp/spark.tgz -C /spark-temp/ \
    && rm /tmp/spark.tg*


#Unpack Spark 
mv /spark-temp/$SPARK_DIR_PATH/ spark
mv spark-env.sh /spark/conf/



#Set up Scala 
export SCALA_VERSION=2.11.8

export SCALA_URL=https://downloads.lightbend.com/scala/$SCALA_VERSION/scala-$SCALA_VERSION.tgz

# UNPACK Scala
mkdir scala-temp
set -x \
    && curl -fSL "$SCALA_URL" -o /tmp/scala.tgz \
    && tar -xvf /tmp/scala.tgz -C /scala-temp/ \
    && rm /tmp/scala.tg*

mv /scala-temp/scala-$SCALA_VERSION/ scala

export HIVE_VERSION=3.0.0
# Set HIVE_VERSION from arg if provided at build, env if provided at run, or default
# https://docs.docker.com/engine/reference/builder/#using-arg-variables
# https://docs.docker.com/engine/reference/builder/#environment-replacement
# ENV HIVE_VERSION=${HIVE_VERSION:-2.3.2}

cd /opt

export HIVE_HOME=/opt/hive
export PATH=$HIVE_HOME/bin:$PATH
export HADOOP_HOME=/opt/hadoop

#Install Hive and PostgreSQL JDBC
apt-get update && apt-get install -y wget procps && \
	wget https://archive.apache.org/dist/hive/hive-$HIVE_VERSION/apache-hive-$HIVE_VERSION-bin.tar.gz && \
	tar -xzvf apache-hive-$HIVE_VERSION-bin.tar.gz && \
    mv apache-hive-$HIVE_VERSION-bin hive && \
	wget https://jdbc.postgresql.org/download/postgresql-9.4.1212.jar -O $HIVE_HOME/lib/postgresql-jdbc.jar && \
	rm apache-hive-$HIVE_VERSION-bin.tar.gz && \
	apt-get --purge remove -y wget && \
	apt-get clean && \
	rm -rf /var/lib/apt/lists/*

rm /opt/hive/lib/guava-19.0.jar
cp /opt/hadoop/share/hadoop/common/lib/guava-27.0-jre.jar /opt/hive/lib/

# move the conf
cd /

cp bee* $HIVE_HOME/conf && cp hive* $HIVE_HOME/conf && cp iv* $HIVE_HOME/conf && cp ll* $HIVE_HOME/conf 

# Append Spark home path -- To be debugged -- There should be proper workaround.. 
# https://github.com/docker/for-linux/issues/395 
# echo 'JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64/' >> /root/.bashrc
# echo 'HADOOP_PREFIX=/opt/hadoop-$HADOOP_VERSION' >> /root/.bashrc
# echo 'HADOOP_CONF_DIR=/etc/hadoop' >> /root/.bashrc
# echo 'MULTIHOMED_NETWORK=1' >> /root/.bashrc
# echo 'USER=root' >> /root/.bashrc
# echo 'PATH=$HADOOP_PREFIX/bin/:$PATH' >> /root/.bashrc
# echo 'export SPARK_HOME=/spark' >> /root/.bashrc
# echo 'export PATH=$PATH:$SPARK_HOME/bin' >> /root/.bashrc
# echo 'export SCALA_HOME=/scala' >> /root/.bashrc
# echo 'export PATH=$PATH:$SCALA_HOME/bin' >> /root/.bashrc
# ###### 
