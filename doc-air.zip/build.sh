#!/bin/bash

pushd base
./build.sh
popd

pushd flower
./build.sh
popd

pushd scheduler
./build.sh
popd

pushd webserver
./build.sh
popd

pushd worker
./build.sh
popd
